#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
/* My code here */
typedef int pid_t;
struct lock file_lock;
void syscall_init (void);
void exit(int);
/*== My code here */
#endif /* userprog/syscall.h */
